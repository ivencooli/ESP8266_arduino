#ifndef BASE64_H
#define BASE64_H

int base64_decode(size_t in_len, const char *in, size_t out_len, unsigned char *out);

#endif